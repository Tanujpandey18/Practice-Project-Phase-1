package com.ecommerce;

public class ProductNotFoundException extends RuntimeException {

}
